/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unipiloto.labmaven.entity;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author david
 */


@XmlRootElement(name="persona")
@XmlType(propOrder = {"id","name","age","salary"})
public class Person {

    //atributos
    private int id;
    private String name;
    private int age;
    private double salary;

    public Person() {

    }
    
    
    @XmlElement
    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
    
    
    @XmlElement
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    @XmlElement
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    @XmlElement 
    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
    

}
