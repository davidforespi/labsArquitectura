/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unipiloto.labmaven;

import co.edu.unipiloto.labmaven.entity.Person;
import static com.sun.research.ws.wadl.HTTPMethods.POST;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import static javax.swing.text.html.FormSubmitEvent.MethodType.GET;
import static javax.swing.text.html.FormSubmitEvent.MethodType.POST;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import static javax.ws.rs.HttpMethod.POST;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author david
 */

@Path("service")
public class Service {
   Person person = new Person();
   private static Map<Integer, Person> persons= new HashMap<Integer,Person>();
   private final double minSalary = 899995;
   static {
       for (int i = 0; i<10; i++){
           Person person = new Person();
           int id = i + 1;
           person.setId(id);
           person.setName("My wonderfull person " + id);
           person.setAge(new Random().nextInt(40)+i);
           person.setSalary(new Random().nextInt(100)+i);
           persons.put(id, person);
       }
       
      
   }
    @GET
    @Path("/getAllPersonsInXML")
    @Produces(MediaType.APPLICATION_XML)
    public List<Person> getAllPersonsInXML(){
       return new ArrayList<>(persons.values());    
    }
   
    @GET
    @Path("/getAllPersonsInJSON")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Person> getAllPersonsInJSON(){
       return new ArrayList<>(persons.values());
    }
    
    @GET
    @Path("/getAllPersonsByIdJSON/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Person getAllPersonsByIdJSON(@PathParam("id") int id){
        return persons.get(id);
    }
    
    @POST
    @Path("/addPersonInJSON")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Person addPersonInJSON(Person person){
       person.setSalary(minSalary*person.getAge()/3); //Calculamos y asignamos el salario
       return persons.put(person.getId(), person);
    }
    
    @GET
    @Path("/getSalary")
    @Produces(MediaType.APPLICATION_JSON)
    public List getSalary(){
        return new ArrayList<>(persons.values());
    }
    
    @GET
    @Path("/avgSalary")
    @Produces(MediaType.TEXT_PLAIN)
    public String avgSalary(){
        String avgSalaryx = Double.toString((double)sumSalary()/ persons.size());
        return avgSalaryx;
    }
    

    @GET
    @Path("/sumSalary")
    @Produces(MediaType.APPLICATION_JSON)
    public double sumSalary(){
        double sum = 0;
        for(Person p: persons.values()){   
            sum += p.getSalary();
        }
        return sum;
    }
    
}
